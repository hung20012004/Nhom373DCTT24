export default function ApplicationLogo(props) {
    return (
        <img src="/logo.png" {...props} alt="Logo" />
    );
}
